# coding:utf-8
# cython:language_level=3
import multiprocessing
import os
import threading
import time
import socket
import logging
from neuro_dance.core import Encoder, Decoder, NdQueue, ProcessMsg, Heart, NdSerial, TCPEncoder, TCPDecoder
heart_seconds = 10
battery_seconds = 60
device_connect_timeout_second = 23


class NdException(Exception):

    def __init__(self, msg):
         self.message = msg

    def __str__(self):
        return self.message


count_per_package_available = [50, 100, 200, 400]
sample_available = [250, 500, 1000, 2000]

serial_mode = "serial"
tcp_mode = "tcp"
# tcp模式是拉数据的方式，100ms拉取一次
tcp_pull_time_span_millisecond = 100


class NdProcess(multiprocessing.Process):

    __mode = None
    __encoder = Encoder()
    __decoder = Decoder()
    __heart = Heart()
    __host_mac_bytes = []
    __device_connect_status = False
    __device_connect_status_last_update_time = None
    __tcp_ip = None
    __tcp_port = None

    def __init__(self, mode, com, tcp_ip, tcp_port, send_queue, recv_queue, host_mac_bytes=None):
        self.__mode = mode
        if host_mac_bytes is not None:
            self.__host_mac_bytes = host_mac_bytes
        self.send_queue = send_queue
        self.recv_queue = recv_queue
        multiprocessing.Process.__init__(self)
        self.com = com
        self.__tcp_ip = tcp_ip
        self.__tcp_port = tcp_port

    def is_ready(self):
        return self.__host_mac_bytes is not None and len(self.__host_mac_bytes) > 0

    def __heartbeat(self, nd_serial):
        if self.is_ready():
            self.__heart.heart_rate(nd_serial, self.__host_mac_bytes)
        else:
            print("Dongle is Not Ready,Please Search Host_Mac First !!!!!!!")

    def run(self):
        print("NdDeviceProc start")
        print("NdDeviceProc pid:{0},mode:{1}".format(os.getpid(), self.__mode))
        if self.__mode == serial_mode:
            self.__serial_run()
        elif self.__mode == tcp_mode:
            self.__tcp_run()
        print("NdDeviceProc {0} Closed".format(self.__mode))

    def __tcp_run(self):
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        last_pull_data_millis_second = None
        try:
            client_socket.connect((self.__tcp_ip, self.__tcp_port))
            req_data = TCPEncoder().req_data()
            decoder = TCPDecoder()
            while True:
                # 请求数据，请求一次，服务端返回一次
                now = int(time.time() * 1000)
                if last_pull_data_millis_second is None or now - last_pull_data_millis_second > tcp_pull_time_span_millisecond:
                    client_socket.sendall(req_data)
                    # 接收服务器返回的数据
                    header_bytes = client_socket.recv(7)
                    header = decoder.decode_bytes(header_bytes)
                    payload_length = header['payload_length']
                    payload_bytes = client_socket.recv(payload_length + 5)
                    channel_data = decoder.decode_bytes(payload_bytes)
                    if channel_data is None or 'key' not in channel_data:
                        continue
                    # print("timestamp:", channel_data['data']['timestamp'])
                    # print("data:", channel_data['data'])
                    self.recv_queue.put(channel_data)
                    # if len(channel_data['data']['data']) == 8:
                    #     print("EEG")
                    #
                    # elif len(channel_data['data']['data']) == 2:
                    #     print("EMG")

                time.sleep(0.05)
        except Exception as e:
            print("Error:", e)
            logging.exception(e)
        finally:
            client_socket.close()

    def __serial_run(self):
        nd_serial = NdSerial()
        nd_serial.open_port(self.com)
        nd_queue = NdQueue()
        last_heartbeat_second = None
        while True:
            # heart
            now = time.time()
            if last_heartbeat_second is None or now - last_heartbeat_second > heart_seconds:
                self.__heartbeat(nd_serial)
                last_heartbeat_second = time.time()
            # consume cmd message
            close = self.__cmd_message_consume(nd_serial)
            if close:
                break
            # decode serial data
            if not nd_serial.is_open():
                time.sleep(0.05)
                continue
            data = nd_serial.read_all()
            if data and len(data) > 0:
                for b in data:
                    nd_queue.en_queue(b)
                res = self.__decoder.decode(nd_queue)
                for msg in res:
                    # host_mac直接获取
                    if msg['key'] == ProcessMsg.host_mac_bytes_info:
                        self.__host_mac_bytes = msg['data']
                    self.recv_queue.put(msg)
            else:
                time.sleep(0.01)

        nd_serial.close()
        self.send_queue.close()
        self.recv_queue.close()

    def send_cmd_from_send_queue(self):
        is_empty = self.send_queue.empty()
        if is_empty:
            return
        self.send_queue.get(block=False)

    # return closed
    def __cmd_message_consume(self, nd_serial):
        # is_empty = self.send_queue.empty()
        # if is_empty:
        #     return
        while not self.send_queue.empty():
            var = self.send_queue.get()
            print("cmd:{0}".format(var['key']))
            if var['key'] == ProcessMsg.close:
                return True
            self.send_cmd(nd_serial, var['key'], var['data'])
        return False

    # 具有value的包括：
    # 配对（mac地址），使能（每包多少点）
    def send_cmd(self, nd_serial, key, value):
        data = None
        if key == ProcessMsg.close:
            # pass关闭线程
            pass
        # -----------------device info --------------
        elif key == ProcessMsg.host_version_info:
            # 获取主机版本号的指令
            data = self.__encoder.host_version()
        elif key == ProcessMsg.host_sn_info:
            data = self.__encoder.host_device_sn()
        elif key == ProcessMsg.host_mac_bytes_info:
            data = self.__encoder.host_device_mac()
        elif key == ProcessMsg.device_version_info:
            self.__device_connect_status_received(True)
            data = self.__encoder.device_version()
        elif key == ProcessMsg.device_mac_info:
            self.__device_connect_status_received(True)
            data = self.__encoder.device_mac()
        elif key == ProcessMsg.device_sn_info:
            self.__device_connect_status_received(True)
            data = self.__encoder.device_sn()
        elif key == ProcessMsg.device_battery_info:
            self.__device_connect_status_received(True)
            data = self.__encoder.device_battery()
        # ------------------ble-------------------------
        elif key == ProcessMsg.ble_scan:
            clean = self.__encoder.device_scan_before()
            self.__cmd_write(nd_serial, clean)
            time.sleep(0.01)
            data = self.__encoder.device_scan()
        elif key == ProcessMsg.ble_pair:
            data = self.__encoder.device_pair(value)
        elif key == ProcessMsg.ble_dis_pair:
            data = self.__encoder.device_dis_pair()
        # -------------------device cfg-----------------------
        elif key == ProcessMsg.device_eeg_channels_config:
            self.__device_connect_status_received(True)
            data = self.__encoder.device_eeg_channel_config(value)
        elif key == ProcessMsg.device_eeg_channels_enable:
            self.__device_connect_status_received(True)
            data = self.__encoder.device_enable_eeg_channel()
        elif key == ProcessMsg.device_eeg_channels_disable:
            self.__device_connect_status_received(True)
            data = self.__encoder.device_disable_eeg_channel()
        elif key == ProcessMsg.device_eog_channels_config:
            self.__device_connect_status_received(True)
            data = self.__encoder.device_eog_channel_config(value)
        elif key == ProcessMsg.device_eog_channels_enable:
            self.__device_connect_status_received(True)
            data = self.__encoder.device_enable_eog_channel()
        elif key == ProcessMsg.device_eog_channels_disable:
            self.__device_connect_status_received(True)
            data = self.__encoder.device_disable_eog_channel()
        if data is not None:
            self.__cmd_write(nd_serial, data)

    def __cmd_write(self, nd_serial, cmd):
        nd_serial.write(cmd)

    def __recv(self, key, data):
        self.recv_queue.put({'key':key, 'data':data})

    def __device_connect_status_received(self, status):
        if status:
            self.__device_connect_status = True
            second_now = int(round(time.time()))
            self.__device_connect_status_last_update_time = second_now
        else:
            self.__device_connect_status = False

    # 23s 没数据，认为断连
    def is_device_connected(self):
        second_now = int(round(time.time()))
        if self.__device_connect_status_last_update_time is None:
            return False
        return self.__device_connect_status and second_now - self.__device_connect_status_last_update_time < 23


class NdDeviceBase(threading.Thread):

    __nd_process = None
    _message_recv = multiprocessing.SimpleQueue()
    _message_send = multiprocessing.SimpleQueue()
    __closed = False
    __device_connect_status = False
    __device_connect_status_last_update_time = None
    __mode = None

    def __init__(self, mode, com, tcp_ip, tcp_port, host_mac_bytes=None):
        threading.Thread.__init__(self)
        self.__mode = mode
        self.__nd_process = NdProcess(mode, com, tcp_ip, tcp_port, self._message_send, self._message_recv, host_mac_bytes)
        self.__nd_process.start()

    def get_mode(self):
        return self.__mode

    def run(self) -> None:
        while not self.__closed:
            self.__consume_recv()
        print("NeuroDancer Closed")

    def __consume_recv(self):
        is_empty = self._message_recv.empty()
        if is_empty:
            time.sleep(0.01)
            return

        var = self._message_recv.get()
        key = var['key']
        data = var['data']
        if key == ProcessMsg.host_version_info:
            self.host_version_received(data)
        elif key == ProcessMsg.host_sn_info:
            self.host_sn_received(data)
        elif key == ProcessMsg.host_mac_bytes_info:
            out_str = ''
            for i in range(0, len(data)):
                out_str = out_str + (hex(int(data[i]))).upper()[2:].zfill(2)
            self.host_mac_received(out_str)
        elif key == ProcessMsg.device_version_info:
            self.device_version_received(data)
        elif key == ProcessMsg.device_mac_info:
            self.__device_connect_status_received(True)
            self.device_mac_received(data)
        elif key == ProcessMsg.device_sn_info:
            self.__device_connect_status_received(True)
            self.device_sn_received(data)
        elif key == ProcessMsg.device_battery_info:
            self.__device_connect_status_received(True)
            self.device_battery_received(data)
        elif key == ProcessMsg.ble_scan:
            self.devices_received(data)
        elif key == ProcessMsg.ble_pair:
            # self.device_dis_pair()
            pass
        elif key == ProcessMsg.ble_dis_pair:
            # self.device_dis_pair()
            pass
        elif key == ProcessMsg.device_eeg_channels_config_response:
            pass
        elif key == ProcessMsg.device_eeg_channels_data:
            self.__device_connect_status_received(True)
            self.eeg_received(data)
        elif key == ProcessMsg.device_eeg_channels_disable_response:
            pass
        elif key == ProcessMsg.device_eog_channels_config_response:
            pass
        elif key == ProcessMsg.device_eog_channels_enable_response:
            pass
        elif key == ProcessMsg.device_eog_channels_disable_response:
            pass
        elif key == ProcessMsg.device_eog_channels_data:
            self.__device_connect_status_received(True)
            self.eog_received(data)
        elif key == ProcessMsg.decode_error:
            self.decode_error()
        elif key == ProcessMsg.crc_error:
            self.crc_error()
        elif key == ProcessMsg.cmd_error:
            self.cmd_error(data[0], data[1], data[2])

    def __device_connect_status_received(self, status):
        if status:
            self.__device_connect_status = True
            second_now = int(round(time.time()))
            self.__device_connect_status_last_update_time = second_now
        else:
            self.__device_connect_status = False

    def is_device_connected(self):
        """ device_connected_status
            :return: true or false
        """
        second_now = int(round(time.time()))
        if self.__device_connect_status_last_update_time is None:
            return False
        return self.__device_connect_status and second_now - self.__device_connect_status_last_update_time < 23

    def eeg_channel_config(self, sample):
        """ eeg 8 channel,sample rate config
        :param: sample: only 250 500 1000 2000 available
        :return: void
        """
        if sample not in sample_available:
            raise NdException("sample rate must in {0}".format(sample_available))
        self.__message_send(ProcessMsg.device_eeg_channels_config, sample)
        time.sleep(0.01)
        self.__message_send(ProcessMsg.device_eeg_channels_config, sample)

    def eeg_channel_enable(self):
        """ eeg 8 channel start transmission
        :param: no param
        :return: void
                  data callback,see function eeg_received()
        """
        self.__message_send(ProcessMsg.device_eeg_channels_enable, None)
        time.sleep(0.01)
        self.__message_send(ProcessMsg.device_eeg_channels_enable, None)

    def eog_channel_config(self, sample):
        """ eog 2 channel,sample rate config
        :param: sample: only 250 500 1000 2000 available
        :return: void
        """
        if sample not in sample_available:
            raise NdException("sample rate must in {0}".format(sample_available))
        self.__message_send(ProcessMsg.device_eog_channels_config, sample)
        time.sleep(0.01)
        self.__message_send(ProcessMsg.device_eog_channels_config, sample)

    def eog_channel_enable(self):
        """ eog 2 channel start transmission
        :param: no param
        :return: void
        """
        self.__message_send(ProcessMsg.device_eog_channels_enable, None)
        time.sleep(0.01)
        self.__message_send(ProcessMsg.device_eog_channels_enable, None)

    def eeg_disable(self):
        """ eeg 8 channel stop transmission
        :param: no param
        :return: void
        """
        self.__message_send(ProcessMsg.device_eeg_channels_disable, None)

    def eog_disable(self):
        """ eog 2 channel stop transmission
        :param: no param
        :return: void
        """
        self.__message_send(ProcessMsg.device_eog_channels_disable, None)

    def host_version_info(self):
        """ search dongle version
        :param: no param
        :return: void
                 dongle version see callback function:host_version_received()
        """
        self.__message_send(ProcessMsg.host_version_info, None)

    def host_mac_info(self):
        """ search dongle mac address
        :param: no param
        :return: void
                 see callback function:host_mac_received()
        """
        self.__message_send(ProcessMsg.host_mac_bytes_info, None)

    def host_sn_info(self):
        """ search dongle sn code
        :param: no param
        :return: void
                 see callback function:host_sn_received()
        """
        self.__message_send(ProcessMsg.host_sn_info, None)

    def host_device_connect(self):
        self.__message_send(ProcessMsg.device_connect_status_info, None)

    # ---------------device info ----------------------
    def device_version_info(self):
        """ search device version code
        :param: no param
        :return: void
                 see callback function:device_version_received()
        """
        self.__message_send(ProcessMsg.device_version_info, None)

    def device_sn_info(self):
        """ search device sn code
        :param: no param
        :return: void
                 see callback function:device_sn_received()
        """
        self.__message_send(ProcessMsg.device_sn_info, None)

    def device_mac_info(self):
        """ search device mac address
        :param: no param
        :return: void
                 see callback function:device_mac_received()
        """
        self.__message_send(ProcessMsg.device_mac_info, None)

    def device_battery(self):
        """ search device battery
        :param: no param
        :return: void
                 see callback function:device_battery_received()
        """
        self.__message_send(ProcessMsg.device_battery_info, None)

    def pair(self, mac):
        """ device ble pair
        :param: mac bytes
        :return: void
        """
        self.__message_send(ProcessMsg.ble_pair, mac)

    def device_scan(self):
        """ device ble scan
        :param: no param
        :return: void
                see callback function:devices_received()
        """
        self.__message_send(ProcessMsg.ble_scan, None)

    def device_dis_pair(self):
        """ device ble dispair
        :param: no param
        :return: void
        """
        self.__message_send(ProcessMsg.ble_dis_pair, None)

    def __message_send(self, key, value):
        self._message_send.put({'key': key, 'data': value})

    def close(self):
        self.__closed = True
        self.__message_send(ProcessMsg.close, None)
        self.__nd_process.join()

    def host_mac_received(self, host_mac):
        print("host mac:{0}".format(host_mac))

    def host_sn_received(self, host_sn):
        print("host sn:{0}".format(host_sn))

    def channel_received(self, data):
        print("channel_received")

    def host_version_received(self, host_version):
        print("host version:{0}".format(host_version))

    def device_mac_received(self, device_mac):
        print("device mac:{0}".format(device_mac))

    def device_sn_received(self, device_sn):
        pass

    def device_battery_received(self, battery):
        pass

    def device_version_received(self, device_version):
        pass

    def eeg_received(self, data):
        """ eeg 8 channel data
        :param: data is dict
                    {'timestamp':11111,
                    'data':[8*n]}

        """
        pass

    def eog_received(self, data):
        """ eog 2 channel data
        :param: data is dict
                    {'timestamp':11111,
                    'data':[2*n]}

        """
        pass

    def devices_received(self, devices):
        pass

    def cmd_error(self, cmd, pm, code):
        print("cmd error:{0},pm:{1},code:{2}".format(cmd, pm, code))

    def crc_error(self):
        print("crc error")

    def decode_error(self):
        print("decode error")